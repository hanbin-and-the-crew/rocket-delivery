package org.sparta.product.domain.enums;

public enum OutboxStatus {
    READY,
    PUBLISHED,
    FAILED
}
